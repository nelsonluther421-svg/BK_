$ErrorActionPreference = "Stop"

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    throw "Flutter is not on PATH. Install the Flutter SDK, reopen PowerShell, and run this script again."
}

Write-Host "Preparing the Kwa Bwatiye Android project..." -ForegroundColor Cyan

if (-not (Test-Path "android\gradlew.bat")) {
    $backupRoot = Join-Path $env:TEMP ("kwa_bwatiye_setup_" + [guid]::NewGuid().ToString("N"))
    $customFiles = @(
        "android\app\build.gradle.kts",
        "android\app\src\main\AndroidManifest.xml",
        "android\app\src\main\kotlin\com\kwabwatiye\dictionary\MainActivity.kt",
        "android\app\src\main\res\drawable\ic_launcher.xml",
        "android\app\src\main\res\drawable\launch_background.xml",
        "android\app\src\main\res\values\styles.xml",
        "android\app\src\main\res\values-night\styles.xml"
    )

    foreach ($file in $customFiles) {
        if (Test-Path $file) {
            $destination = Join-Path $backupRoot $file
            New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
            Copy-Item $file $destination -Force
        }
    }

    flutter create . --platforms=android --project-name kwa_bwatiye --org com.kwabwatiye

    foreach ($file in $customFiles) {
        $source = Join-Path $backupRoot $file
        if (Test-Path $source) {
            New-Item -ItemType Directory -Force -Path (Split-Path $file) | Out-Null
            Copy-Item $source $file -Force
        }
    }
    Remove-Item $backupRoot -Recurse -Force
}

flutter pub get
flutter analyze
flutter test

Write-Host "`nSetup complete. Connect an Android phone or open an emulator, then run: flutter run" -ForegroundColor Green
