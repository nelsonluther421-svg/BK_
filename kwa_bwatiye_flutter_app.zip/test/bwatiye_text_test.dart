import 'package:flutter_test/flutter_test.dart';
import 'package:kwa_bwatiye/bwatiye_text.dart';

void main() {
  group('Bwaatiye text folding', () {
    test('removes tone marks and hooked letters for phone-keyboard search', () {
      expect(fold('ɓòòlé'), 'boole');
      expect(fold('háɓyé'), 'habye');
      expect(fold('ɗöŋ'), 'dong');
    });

    test('loose folding removes reference punctuation', () {
      expect(foldLoose('(à)hyékútö'), 'ahyekuto');
    });

    test('LIKE escaping protects wildcard characters', () {
      expect(escapeLike(r'a_b%'), r'a\_b\%');
    });
  });
}
