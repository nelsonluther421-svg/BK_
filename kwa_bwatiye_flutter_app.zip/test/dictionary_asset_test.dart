import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('bundled dictionary JSON has complete structured coverage', () async {
    final source = await rootBundle.loadString('assets/bwatiye_dictionary.json');
    final entries = jsonDecode(source) as List<dynamic>;

    expect(entries, hasLength(2132));
    for (final value in entries) {
      final entry = value as Map<String, dynamic>;
      expect(entry['id'], isNotEmpty);
      expect(entry['headword'], isNotEmpty);
      expect(entry['gloss'], isNotEmpty);
      expect(entry['source_page'], isA<int>());
    }
  });
}
