import 'package:flutter/material.dart';

import '../app.dart';
import '../models/dictionary_entry.dart';
import '../theme/app_theme.dart';
import '../widgets/entry_tile.dart';
import 'entry_detail_screen.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  String _signature = '';
  Future<List<DictionaryEntry>>? _entries;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final controller = AppScope.of(context);
    final ids = controller.favoriteIds.toList()..sort();
    final signature = ids.join('|');
    if (signature != _signature) {
      _signature = signature;
      _entries = _loadEntries(ids);
    }
  }

  Future<List<DictionaryEntry>> _loadEntries(List<String> ids) async {
    final repository = AppScope.of(context, listen: false).repository;
    final entries = <DictionaryEntry>[];
    for (final id in ids) {
      final entry = await repository.getById(id);
      if (entry != null) entries.add(entry);
    }
    entries.sort((a, b) => a.sortkey.compareTo(b.sortkey));
    return entries;
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'YOUR COLLECTION',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4),
            ),
            Text(
              'Saved words',
              style: TextStyle(fontFamily: 'serif', fontSize: 25, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
      body: FutureBuilder<List<DictionaryEntry>>(
        future: _entries ?? Future.value(const <DictionaryEntry>[]),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final entries = snapshot.data ?? const <DictionaryEntry>[];
          if (entries.isEmpty) return const _EmptySaved();
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
            itemCount: entries.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final entry = entries[index];
              return EntryTile(
                entry: entry,
                isFavorite: controller.isFavorite(entry.id),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => EntryDetailScreen(entry: entry),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _EmptySaved extends StatelessWidget {
  const _EmptySaved();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(34),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 34,
              backgroundColor: AppColors.goldSoft,
              foregroundColor: AppColors.clay,
              child: Icon(Icons.bookmark_add_outlined, size: 32),
            ),
            SizedBox(height: 18),
            Text(
              'Build your word collection',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.ink,
                fontFamily: 'serif',
                fontSize: 24,
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Open any dictionary entry and tap the bookmark to save it here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}
