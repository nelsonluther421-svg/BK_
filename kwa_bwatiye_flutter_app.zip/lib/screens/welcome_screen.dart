import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key, required this.onContinue});

  final Future<void> Function() onContinue;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFF9ED), AppColors.cream],
          ),
        ),
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight - 48),
                  child: IntrinsicHeight(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const _WelcomeHeader(),
                        const SizedBox(height: 28),
                        Text(
                          'Bware Hido,\nJiya Hido',
                          style: Theme.of(context).textTheme.displayLarge,
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Preserving our language, one word and one voice at a time.',
                          style: TextStyle(
                            color: AppColors.muted,
                            fontSize: 16,
                            height: 1.55,
                          ),
                        ),
                        const SizedBox(height: 22),
                        const Expanded(
                          child: ConstrainedBox(
                            constraints: BoxConstraints(minHeight: 270),
                            child: CustomPaint(
                              painter: _HeritageScenePainter(),
                              child: SizedBox.expand(),
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        FilledButton(
                          onPressed: onContinue,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text('WAYAM PEPE'),
                              SizedBox(width: 10),
                              Icon(Icons.arrow_forward_rounded, size: 20),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Bwaatiye · Bachama–English Dictionary',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppColors.muted,
                            fontSize: 11,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _WelcomeHeader extends StatelessWidget {
  const _WelcomeHeader();

  @override
  Widget build(BuildContext context) {
    return const Row(
      children: [
        BrandMark(size: 44),
        SizedBox(width: 15),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'KWA BWATIYE',
              style: TextStyle(
                color: AppColors.ink,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.6,
              ),
            ),
            SizedBox(height: 2),
            Text(
              'OUR WORDS · OUR VOICES',
              style: TextStyle(
                color: AppColors.clay,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _HeritageScenePainter extends CustomPainter {
  const _HeritageScenePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final radius = Radius.circular(math.min(34, size.width * 0.08));
    final clip = RRect.fromRectAndRadius(rect, radius);
    canvas.save();
    canvas.clipRRect(clip);

    final sky = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFFF2C875), Color(0xFFD77B48)],
      ).createShader(rect);
    canvas.drawRect(rect, sky);

    final sun = Paint()..color = const Color(0xFFFFE9AD);
    canvas.drawCircle(
      Offset(size.width * 0.74, size.height * 0.28),
      size.shortestSide * 0.18,
      sun,
    );

    final farHill = Path()
      ..moveTo(0, size.height * 0.62)
      ..quadraticBezierTo(size.width * 0.22, size.height * 0.48,
          size.width * 0.48, size.height * 0.62)
      ..quadraticBezierTo(size.width * 0.75, size.height * 0.76,
          size.width, size.height * 0.54)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(farHill, Paint()..color = const Color(0xFF834735));

    final nearHill = Path()
      ..moveTo(0, size.height * 0.76)
      ..quadraticBezierTo(size.width * 0.35, size.height * 0.58,
          size.width * 0.62, size.height * 0.8)
      ..quadraticBezierTo(size.width * 0.82, size.height * 0.92,
          size.width, size.height * 0.7)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(nearHill, Paint()..color = AppColors.forestDark);

    _paintFigure(canvas, Offset(size.width * 0.34, size.height * 0.58),
        size.shortestSide * 0.14, false);
    _paintFigure(canvas, Offset(size.width * 0.58, size.height * 0.61),
        size.shortestSide * 0.13, true);

    final motif = Paint()
      ..color = const Color(0xCCF9F2E5)
      ..strokeWidth = 2;
    for (var x = -20.0; x < size.width + 20; x += 24) {
      canvas.drawLine(Offset(x, size.height - 13),
          Offset(x + 12, size.height - 25), motif);
      canvas.drawLine(Offset(x + 12, size.height - 25),
          Offset(x + 24, size.height - 13), motif);
    }
    canvas.restore();
  }

  void _paintFigure(
    Canvas canvas,
    Offset origin,
    double unit,
    bool mirrored,
  ) {
    canvas.save();
    canvas.translate(origin.dx, origin.dy);
    canvas.scale(mirrored ? -1 : 1, 1);
    final silhouette = Paint()
      ..color = const Color(0xFF1C2822)
      ..style = PaintingStyle.fill;
    final stroke = Paint()
      ..color = const Color(0xFF1C2822)
      ..style = PaintingStyle.stroke
      ..strokeWidth = unit * 0.13
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(Offset(0, -unit * 0.85), unit * 0.22, silhouette);
    canvas.drawLine(Offset(0, -unit * 0.58), Offset(0, unit * 0.35), stroke);
    canvas.drawLine(Offset(0, -unit * 0.35), Offset(unit * 0.52, -unit * 0.02), stroke);
    canvas.drawLine(Offset(0, -unit * 0.3), Offset(unit * 0.48, unit * 0.17), stroke);
    canvas.drawLine(Offset(0, unit * 0.32), Offset(-unit * 0.25, unit), stroke);
    canvas.drawLine(Offset(0, unit * 0.32), Offset(unit * 0.3, unit), stroke);

    final drum = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(unit * 0.66, unit * 0.08),
        width: unit * 0.52,
        height: unit * 0.72,
      ),
      Radius.circular(unit * 0.14),
    );
    canvas.drawRRect(drum, Paint()..color = AppColors.gold);
    canvas.drawLine(
      Offset(unit * 0.62, -unit * 0.27),
      Offset(unit * 0.7, unit * 0.43),
      Paint()
        ..color = AppColors.clayDark
        ..strokeWidth = unit * 0.05,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
