import 'package:flutter/material.dart';

import '../app.dart';
import '../models/dictionary_entry.dart';
import '../widgets/entry_tile.dart';
import 'entry_detail_screen.dart';

class LetterBrowseScreen extends StatelessWidget {
  const LetterBrowseScreen({super.key, required this.letter});

  final String letter;

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: Text('Words beginning with $letter')),
      body: FutureBuilder<List<DictionaryEntry>>(
        future: controller.repository.browseLetter(letter),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final entries = snapshot.data ?? const <DictionaryEntry>[];
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
            itemCount: entries.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final entry = entries[index];
              return EntryTile(
                entry: entry,
                isFavorite: controller.isFavorite(entry.id),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => EntryDetailScreen(entry: entry),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
