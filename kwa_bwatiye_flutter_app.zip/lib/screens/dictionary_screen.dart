import 'package:flutter/material.dart';

import '../app.dart';
import '../bwatiye_text.dart';
import '../models/dictionary_entry.dart';
import '../theme/app_theme.dart';
import '../widgets/entry_tile.dart';
import 'entry_detail_screen.dart';
import 'search_screen.dart';

class DictionaryScreen extends StatefulWidget {
  const DictionaryScreen({super.key});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  String _letter = 'a';
  Future<List<DictionaryEntry>>? _entries;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _entries ??= AppScope.of(context, listen: false).repository.browseLetter(_letter);
  }

  void _selectLetter(String letter) {
    final repository = AppScope.of(context, listen: false).repository;
    setState(() {
      _letter = letter;
      _entries = letter == 'all'
          ? repository.browse(limit: 200)
          : repository.browseLetter(letter);
    });
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'DICTIONARY',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5),
            ),
            Text(
              'Browse Bwaatiye',
              style: TextStyle(fontFamily: 'serif', fontSize: 25, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Search',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SearchScreen()),
            ),
            icon: const Icon(Icons.search_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 58,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
              scrollDirection: Axis.horizontal,
              itemCount: bwatiyeAlphabet.length + 1,
              separatorBuilder: (_, __) => const SizedBox(width: 7),
              itemBuilder: (context, index) {
                final letter = index == 0 ? 'all' : bwatiyeAlphabet[index - 1];
                final selected = _letter == letter;
                return ChoiceChip(
                  selected: selected,
                  onSelected: (_) => _selectLetter(letter),
                  label: Text(letter == 'all' ? 'All' : letter),
                  labelStyle: TextStyle(
                    color: selected ? Colors.white : AppColors.ink,
                    fontWeight: FontWeight.w800,
                  ),
                  selectedColor: AppColors.clay,
                  backgroundColor: AppColors.paper,
                  side: BorderSide(color: selected ? AppColors.clay : AppColors.line),
                  showCheckmark: false,
                );
              },
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: FutureBuilder<List<DictionaryEntry>>(
              future: _entries,
              builder: (context, snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return _LoadError(onRetry: () => _selectLetter(_letter));
                }
                final entries = snapshot.data ?? const <DictionaryEntry>[];
                if (entries.isEmpty) {
                  return const _EmptyLetter();
                }
                return RefreshIndicator(
                  onRefresh: () async => _selectLetter(_letter),
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
                    itemCount: entries.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final entry = entries[index];
                      return EntryTile(
                        entry: entry,
                        isFavorite: controller.isFavorite(entry.id),
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => EntryDetailScreen(entry: entry),
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _LoadError extends StatelessWidget {
  const _LoadError({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, color: AppColors.clay, size: 38),
            const SizedBox(height: 14),
            const Text('Entries could not be loaded.'),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: onRetry, child: const Text('Try again')),
          ],
        ),
      ),
    );
  }
}

class _EmptyLetter extends StatelessWidget {
  const _EmptyLetter();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(30),
        child: Text(
          'No entries begin with this letter in the supplied dictionary.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
      ),
    );
  }
}
