import 'package:flutter/material.dart';

import '../app.dart';
import '../models/dictionary_entry.dart';
import '../theme/app_theme.dart';
import '../widgets/entry_tile.dart';
import 'entry_detail_screen.dart';

class VoiceArchiveScreen extends StatefulWidget {
  const VoiceArchiveScreen({super.key});

  @override
  State<VoiceArchiveScreen> createState() => _VoiceArchiveScreenState();
}

class _VoiceArchiveScreenState extends State<VoiceArchiveScreen> {
  Future<List<DictionaryEntry>>? _recordings;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _recordings ??= _load();
  }

  Future<List<DictionaryEntry>> _load() async {
    final controller = AppScope.of(context, listen: false);
    final ids = await controller.voice.recordedEntryIds();
    final entries = <DictionaryEntry>[];
    for (final id in ids) {
      final entry = await controller.repository.getById(id);
      if (entry != null) entries.add(entry);
    }
    entries.sort((a, b) => a.sortkey.compareTo(b.sortkey));
    return entries;
  }

  Future<void> _refresh() async {
    setState(() => _recordings = _load());
    await _recordings;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Voice archive')),
      body: FutureBuilder<List<DictionaryEntry>>(
        future: _recordings,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final entries = snapshot.data ?? const <DictionaryEntry>[];
          if (entries.isEmpty) return const _EmptyVoiceArchive();
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
              itemCount: entries.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final entry = entries[index];
                return EntryTile(
                  entry: entry,
                  matchCaption: 'Local pronunciation recording',
                  onTap: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => EntryDetailScreen(entry: entry),
                      ),
                    );
                    if (mounted) await _refresh();
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class _EmptyVoiceArchive extends StatelessWidget {
  const _EmptyVoiceArchive();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(34),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 34,
              backgroundColor: AppColors.goldSoft,
              foregroundColor: AppColors.clay,
              child: Icon(Icons.graphic_eq_rounded, size: 33),
            ),
            SizedBox(height: 18),
            Text(
              'Keep the voice',
              style: TextStyle(
                color: AppColors.ink,
                fontFamily: 'serif',
                fontSize: 25,
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Open an entry and record a fluent speaker. Local drafts will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}
