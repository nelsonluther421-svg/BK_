import 'package:flutter/material.dart';

import '../app.dart';
import '../bwatiye_text.dart';
import '../models/dictionary_entry.dart';
import '../theme/app_theme.dart';
import '../widgets/section_label.dart';
import 'entry_detail_screen.dart';
import 'letter_browse_screen.dart';
import 'search_screen.dart';
import 'voice_archive_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.onOpenDictionary,
    required this.onOpenSaved,
  });

  final VoidCallback onOpenDictionary;
  final VoidCallback onOpenSaved;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  DictionaryEntry? _wordOfTheDay;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_wordOfTheDay == null) _loadWordOfTheDay();
  }

  Future<void> _loadWordOfTheDay() async {
    final controller = AppScope.of(context, listen: false);
    if (controller.dictionaryCount == 0) return;
    final day = DateTime.now().difference(DateTime(2024)).inDays;
    final entries = await controller.repository.browse(
      limit: 1,
      offset: day % controller.dictionaryCount,
    );
    if (!mounted || entries.isEmpty) return;
    setState(() => _wordOfTheDay = entries.first);
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              sliver: SliverList.list(
                children: [
                  const _HomeHeader(),
                  const SizedBox(height: 34),
                  Text(
                    'Find the word.\nKeep the voice.',
                    style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                          fontSize: 42,
                          height: 1.02,
                        ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Search Bwaatiye and English, explore every entry, and preserve pronunciation with real voices.',
                    style: TextStyle(color: AppColors.muted, height: 1.55),
                  ),
                  const SizedBox(height: 22),
                  TextField(
                    readOnly: true,
                    onTap: () => _openSearch(context),
                    decoration: const InputDecoration(
                      hintText: 'Search a word or meaning…',
                      prefixIcon: Icon(Icons.search_rounded),
                      suffixIcon: Icon(Icons.tune_rounded),
                    ),
                  ),
                  const SizedBox(height: 18),
                  _StatsStrip(
                    entryCount: controller.dictionaryCount,
                    savedCount: controller.favoriteIds.length,
                  ),
                  const SizedBox(height: 30),
                  const SectionLabel('Word of the day'),
                  const SizedBox(height: 12),
                  _WordCard(
                    entry: _wordOfTheDay,
                    onTap: _wordOfTheDay == null
                        ? null
                        : () => _openEntry(context, _wordOfTheDay!),
                  ),
                  const SizedBox(height: 30),
                  const SectionLabel('Explore'),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _ActionCard(
                          icon: Icons.menu_book_rounded,
                          title: 'Dictionary',
                          subtitle: 'Browse all words',
                          color: AppColors.forest,
                          onTap: widget.onOpenDictionary,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _ActionCard(
                          icon: Icons.graphic_eq_rounded,
                          title: 'Voice archive',
                          subtitle: 'Your recordings',
                          color: AppColors.clay,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const VoiceArchiveScreen(),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  SectionLabel(
                    'Bwaatiye alphabet',
                    trailing: TextButton(
                      onPressed: widget.onOpenDictionary,
                      child: const Text('See all'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 48,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: bwatiyeAlphabet.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, index) {
                        final letter = bwatiyeAlphabet[index];
                        return _LetterChip(
                          letter: letter,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => LetterBrowseScreen(letter: letter),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openSearch(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const SearchScreen()),
    );
  }

  void _openEntry(BuildContext context, DictionaryEntry entry) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => EntryDetailScreen(entry: entry)),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  const _HomeHeader();

  @override
  Widget build(BuildContext context) {
    return const Row(
      children: [
        BrandMark(),
        SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'KWA BWATIYE',
                style: TextStyle(
                  color: AppColors.ink,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              Text(
                'Bwaatiye–English Dictionary',
                style: TextStyle(color: AppColors.muted, fontSize: 11),
              ),
            ],
          ),
        ),
        _OfflineBadge(),
      ],
    );
  }
}

class _OfflineBadge extends StatelessWidget {
  const _OfflineBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFFE1EADF),
        borderRadius: BorderRadius.circular(999),
      ),
      child: const Row(
        children: [
          Icon(Icons.offline_bolt_rounded, size: 14, color: AppColors.forest),
          SizedBox(width: 5),
          Text(
            'OFFLINE',
            style: TextStyle(
              color: AppColors.forest,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.7,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatsStrip extends StatelessWidget {
  const _StatsStrip({required this.entryCount, required this.savedCount});

  final int entryCount;
  final int savedCount;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 15),
      decoration: BoxDecoration(
        color: AppColors.paper,
        border: Border.all(color: AppColors.line),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Expanded(child: _Stat(value: '$entryCount', label: 'Entries')),
          const SizedBox(height: 34, child: VerticalDivider()),
          const Expanded(child: _Stat(value: '101', label: 'Source pages')),
          const SizedBox(height: 34, child: VerticalDivider()),
          Expanded(child: _Stat(value: '$savedCount', label: 'Saved')),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: AppColors.ink,
            fontSize: 18,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
      ],
    );
  }
}

class _WordCard extends StatelessWidget {
  const _WordCard({required this.entry, required this.onTap});

  final DictionaryEntry? entry;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Ink(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.forest, AppColors.forestDark],
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: entry == null
              ? const SizedBox(
                  height: 88,
                  child: Center(
                    child: CircularProgressIndicator(color: AppColors.gold),
                  ),
                )
              : Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            entry!.headword,
                            style: const TextStyle(
                              color: AppColors.cream,
                              fontFamily: 'serif',
                              fontSize: 34,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            entry!.gloss,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Color(0xDDF9F2E5),
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    const CircleAvatar(
                      backgroundColor: Color(0x22FFFFFF),
                      foregroundColor: AppColors.gold,
                      child: Icon(Icons.arrow_forward_rounded),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(
            color: AppColors.paper,
            border: Border.all(color: AppColors.line),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(icon, color: Colors.white, size: 21),
              ),
              const SizedBox(height: 18),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: const TextStyle(color: AppColors.muted, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LetterChip extends StatelessWidget {
  const _LetterChip({required this.letter, required this.onTap});

  final String letter;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      onPressed: onTap,
      label: Text(
        letter,
        style: const TextStyle(
          color: AppColors.ink,
          fontFamily: 'serif',
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
      backgroundColor: AppColors.paper,
      side: const BorderSide(color: AppColors.line),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
    );
  }
}
