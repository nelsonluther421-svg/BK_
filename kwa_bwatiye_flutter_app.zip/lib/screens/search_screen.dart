import 'dart:async';

import 'package:flutter/material.dart';

import '../app.dart';
import '../dictionary_repository.dart';
import '../models/dictionary_entry.dart';
import '../state/app_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/entry_tile.dart';
import 'entry_detail_screen.dart';

enum _SearchMode { all, bwatiye, english }

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, this.initialQuery = ''});

  final String initialQuery;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late final TextEditingController _textController;
  Timer? _debounce;
  _SearchMode _mode = _SearchMode.all;
  List<_DisplayResult> _results = const [];
  bool _searching = false;
  String? _error;
  int _requestToken = 0;

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController(text: widget.initialQuery);
    if (widget.initialQuery.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _runSearch());
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _textController.dispose();
    super.dispose();
  }

  void _onQueryChanged(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 260), _runSearch);
  }

  Future<void> _runSearch() async {
    final query = _textController.text.trim();
    final token = ++_requestToken;
    if (query.isEmpty) {
      setState(() {
        _results = const [];
        _searching = false;
        _error = null;
      });
      return;
    }

    setState(() {
      _searching = true;
      _error = null;
    });

    try {
      final repository = AppScope.of(context, listen: false).repository;
      final List<_DisplayResult> results;
      switch (_mode) {
        case _SearchMode.all:
          final hits = await repository.search(query);
          results = hits.map(_DisplayResult.fromSearchResult).toList();
          break;
        case _SearchMode.bwatiye:
          final hits = await repository.searchByPrefix(query);
          results = hits.map(_DisplayResult.fromSearchResult).toList();
          break;
        case _SearchMode.english:
          final entries = await repository.searchEnglish(query);
          results = entries
              .map((entry) => _DisplayResult(entry, 'Matched English meaning'))
              .toList();
          break;
      }
      if (!mounted || token != _requestToken) return;
      setState(() {
        _results = results;
        _searching = false;
      });
    } catch (_) {
      if (!mounted || token != _requestToken) return;
      setState(() {
        _searching = false;
        _error = 'Search could not be completed.';
      });
    }
  }

  void _setMode(_SearchMode mode) {
    setState(() => _mode = mode);
    _runSearch();
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Search dictionary')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: TextField(
              controller: _textController,
              autofocus: true,
              textInputAction: TextInputAction.search,
              onChanged: _onQueryChanged,
              onSubmitted: (_) => _runSearch(),
              decoration: InputDecoration(
                hintText: 'Bwaatiye word or English meaning…',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _textController.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _textController.clear();
                          _runSearch();
                          setState(() {});
                        },
                        icon: const Icon(Icons.close_rounded),
                      ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SegmentedButton<_SearchMode>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: _SearchMode.all, label: Text('All')),
                ButtonSegment(value: _SearchMode.bwatiye, label: Text('Bwaatiye')),
                ButtonSegment(value: _SearchMode.english, label: Text('English')),
              ],
              selected: {_mode},
              onSelectionChanged: (selection) => _setMode(selection.first),
            ),
          ),
          const SizedBox(height: 10),
          if (_searching) const LinearProgressIndicator(minHeight: 2),
          Expanded(
            child: _buildBody(controller),
          ),
        ],
      ),
    );
  }

  Widget _buildBody(AppController controller) {
    if (_error != null) {
      return Center(child: Text(_error!, style: const TextStyle(color: AppColors.clay)));
    }
    if (_textController.text.trim().isEmpty) {
      return const _SearchPrompt();
    }
    if (!_searching && _results.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'No matching dictionary entry was found. Try the plain-letter spelling or switch the search language.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.muted, height: 1.5),
          ),
        ),
      );
    }
    return ListView.separated(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
      itemCount: _results.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final result = _results[index];
        return EntryTile(
          entry: result.entry,
          matchCaption: result.caption,
          isFavorite: controller.isFavorite(result.entry.id),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => EntryDetailScreen(entry: result.entry),
            ),
          ),
        );
      },
    );
  }
}

class _DisplayResult {
  const _DisplayResult(this.entry, this.caption);

  final DictionaryEntry entry;
  final String? caption;

  factory _DisplayResult.fromSearchResult(SearchResult result) {
    final caption = switch (result.source) {
      MatchSource.headword => 'Matched Bwaatiye headword',
      MatchSource.alias => result.matchedAlias == null
          ? 'Matched a related form'
          : 'Matched form: ${result.matchedAlias}',
      MatchSource.gloss => 'Matched English meaning',
      MatchSource.example => 'Matched an example phrase',
    };
    return _DisplayResult(result.entry, caption);
  }
}

class _SearchPrompt extends StatelessWidget {
  const _SearchPrompt();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(34),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.manage_search_rounded, color: AppColors.gold, size: 58),
            SizedBox(height: 16),
            Text(
              'Search in either language',
              style: TextStyle(
                color: AppColors.ink,
                fontFamily: 'serif',
                fontSize: 23,
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Tone marks and special letters are optional. For example, a plain keyboard spelling can still find the Bwaatiye form.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}
