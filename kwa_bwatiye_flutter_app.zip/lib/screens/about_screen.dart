import 'package:flutter/material.dart';

import '../app.dart';
import '../theme/app_theme.dart';
import '../widgets/section_label.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'About',
          style: TextStyle(fontFamily: 'serif', fontSize: 25, fontWeight: FontWeight.w700),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 34),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.forest,
              borderRadius: BorderRadius.circular(26),
            ),
            child: Column(
              children: [
                const BrandMark(size: 58, onDark: true),
                const SizedBox(height: 22),
                const Text(
                  'Kwa Bwatiye',
                  style: TextStyle(
                    color: AppColors.cream,
                    fontFamily: 'serif',
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'BWARE HIDO, JIYA HIDO',
                  style: TextStyle(
                    color: AppColors.gold,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
                const SizedBox(height: 15),
                Text(
                  '${controller.dictionaryCount} entries available offline',
                  style: const TextStyle(color: Color(0xCCFFFFFF), fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          const SectionLabel('Purpose'),
          const SizedBox(height: 10),
          const _AboutCard(
            child: Text(
              'Kwa Bwatiye is a mobile-first dictionary for finding Bwaatiye words, looking up English meanings, following related forms, and preserving pronunciation through recordings made by real speakers.',
              style: TextStyle(height: 1.6),
            ),
          ),
          const SizedBox(height: 24),
          const SectionLabel('Dictionary source'),
          const SizedBox(height: 10),
          const _AboutCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Bwaatiye–English Dictionary',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                ),
                SizedBox(height: 6),
                Text(
                  'Nicholas Pweddon and A. Neil Skinner',
                  style: TextStyle(color: AppColors.clay, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 12),
                Text(
                  'The bundled data covers the Bwaatiye-to-English section on printed pages 1–101. Each entry keeps its source page when available.',
                  style: TextStyle(color: AppColors.muted, height: 1.55),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const SectionLabel('Privacy & voice'),
          const SizedBox(height: 10),
          const _AboutCard(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.shield_outlined, color: AppColors.forest),
                SizedBox(width: 13),
                Expanded(
                  child: Text(
                    'The dictionary works offline. Saved words and pronunciation drafts stay on the device. Recordings are never marked as verified automatically.',
                    style: TextStyle(height: 1.55),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          const Center(
            child: Text(
              'WAYAM PEPE',
              style: TextStyle(
                color: AppColors.clay,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AboutCard extends StatelessWidget {
  const _AboutCard({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.paper,
        border: Border.all(color: AppColors.line),
        borderRadius: BorderRadius.circular(19),
      ),
      child: child,
    );
  }
}
