import 'package:flutter/material.dart';

import '../app.dart';
import '../models/dictionary_entry.dart';
import '../theme/app_theme.dart';
import '../widgets/section_label.dart';
import '../widgets/voice_recording_card.dart';

class EntryDetailScreen extends StatelessWidget {
  const EntryDetailScreen({super.key, required this.entry});

  final DictionaryEntry entry;

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    final favorite = controller.isFavorite(entry.id);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dictionary entry'),
        actions: [
          IconButton(
            tooltip: favorite ? 'Remove saved word' : 'Save word',
            onPressed: () => controller.toggleFavorite(entry.id),
            icon: Icon(
              favorite ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
              color: favorite ? AppColors.gold : null,
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 36),
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (entry.pos?.isNotEmpty == true) _DetailBadge(entry.pos!),
              if (entry.sourcePage != null) _DetailBadge('Source page ${entry.sourcePage}'),
              const _DetailBadge('Bwaatiye → English'),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            entry.headword,
            style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: 52),
          ),
          const SizedBox(height: 12),
          Text(
            entry.gloss,
            style: const TextStyle(
              color: AppColors.clay,
              fontFamily: 'serif',
              fontSize: 26,
              height: 1.25,
              fontWeight: FontWeight.w600,
            ),
          ),
          if (_hasForms(entry)) ...[
            const SizedBox(height: 28),
            const SectionLabel('Forms & notes'),
            const SizedBox(height: 10),
            _InformationCard(entry: entry),
          ],
          if (entry.aliases.isNotEmpty) ...[
            const SizedBox(height: 28),
            const SectionLabel('Related forms'),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: entry.aliases
                  .map((alias) => _AliasChip(alias: alias))
                  .toList(),
            ),
          ],
          if (entry.examples.isNotEmpty) ...[
            const SizedBox(height: 28),
            const SectionLabel('Examples'),
            const SizedBox(height: 10),
            ...entry.examples.map((example) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ExampleCard(example: example),
                )),
          ],
          if (entry.crossReferences.isNotEmpty) ...[
            const SizedBox(height: 28),
            const SectionLabel('See also'),
            const SizedBox(height: 8),
            ...entry.crossReferences.map((reference) => _ReferenceTile(
                  reference: reference,
                  onOpen: reference.isResolved
                      ? () => _openReference(context, reference)
                      : null,
                )),
          ],
          const SizedBox(height: 28),
          VoiceRecordingCard(entry: entry),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.paper,
              border: Border.all(color: AppColors.line),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.library_books_outlined, color: AppColors.clay, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    entry.sourcePage == null
                        ? 'Entry transcribed from the supplied Bwaatiye–English Dictionary data.'
                        : 'Entry transcribed from printed source page ${entry.sourcePage}.',
                    style: const TextStyle(color: AppColors.muted, fontSize: 11, height: 1.45),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool _hasForms(DictionaryEntry value) {
    return value.plural?.isNotEmpty == true ||
        value.scientificName?.isNotEmpty == true ||
        value.notes?.isNotEmpty == true;
  }

  Future<void> _openReference(
    BuildContext context,
    CrossReference reference,
  ) async {
    final repository = AppScope.of(context, listen: false).repository;
    final target = await repository.follow(reference);
    if (!context.mounted || target == null) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => EntryDetailScreen(entry: target)),
    );
  }
}

class _DetailBadge extends StatelessWidget {
  const _DetailBadge(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.goldSoft,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: AppColors.clayDark,
          fontSize: 9,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.6,
        ),
      ),
    );
  }
}

class _InformationCard extends StatelessWidget {
  const _InformationCard({required this.entry});

  final DictionaryEntry entry;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: AppColors.paper,
        border: Border.all(color: AppColors.line),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: [
          if (entry.plural?.isNotEmpty == true)
            _InfoRow(label: 'Plural', value: entry.plural!),
          if (entry.scientificName?.isNotEmpty == true)
            _InfoRow(label: 'Scientific', value: entry.scientificName!),
          if (entry.notes?.isNotEmpty == true)
            _InfoRow(label: 'Notes', value: entry.notes!, last: true),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value, this.last = false});

  final String label;
  final String value;
  final bool last;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: last
          ? null
          : const BoxDecoration(
              border: Border(bottom: BorderSide(color: AppColors.line)),
            ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 88,
            child: Text(
              label.toUpperCase(),
              style: const TextStyle(
                color: AppColors.muted,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.7,
              ),
            ),
          ),
          Expanded(child: Text(value, style: const TextStyle(height: 1.45))),
        ],
      ),
    );
  }
}

class _AliasChip extends StatelessWidget {
  const _AliasChip({required this.alias});

  final EntryAlias alias;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: AppColors.paper,
        border: Border.all(color: AppColors.line),
        borderRadius: BorderRadius.circular(13),
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: AppColors.ink, fontSize: 13),
          children: [
            TextSpan(
              text: alias.alias,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            if (alias.label?.isNotEmpty == true)
              TextSpan(
                text: '  ${alias.label}',
                style: const TextStyle(color: AppColors.muted, fontSize: 10),
              ),
          ],
        ),
      ),
    );
  }
}

class _ExampleCard extends StatelessWidget {
  const _ExampleCard({required this.example});

  final DictionaryExample example;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: AppColors.paper,
        border: Border.all(color: AppColors.line),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (example.bwatiye?.isNotEmpty == true)
            Text(
              example.bwatiye!,
              style: const TextStyle(
                color: AppColors.ink,
                fontFamily: 'serif',
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          if (example.english?.isNotEmpty == true) ...[
            const SizedBox(height: 6),
            Text(
              example.english!,
              style: const TextStyle(color: AppColors.muted, height: 1.45),
            ),
          ],
        ],
      ),
    );
  }
}

class _ReferenceTile extends StatelessWidget {
  const _ReferenceTile({required this.reference, required this.onOpen});

  final CrossReference reference;
  final VoidCallback? onOpen;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      onTap: onOpen,
      leading: CircleAvatar(
        backgroundColor: reference.isResolved ? AppColors.goldSoft : AppColors.line,
        foregroundColor: reference.isResolved ? AppColors.clayDark : AppColors.muted,
        child: Icon(reference.isResolved ? Icons.call_made_rounded : Icons.link_off_rounded),
      ),
      title: Text(reference.refText, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: reference.isInferred
          ? Text('Inferred link · ${reference.matchKind}')
          : reference.isResolved
              ? const Text('Open dictionary entry')
              : const Text('No target entry in the printed source'),
      trailing: reference.isResolved ? const Icon(Icons.chevron_right_rounded) : null,
    );
  }
}
