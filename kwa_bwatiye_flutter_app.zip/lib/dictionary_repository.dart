import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import 'bwatiye_text.dart';
import 'models/dictionary_entry.dart';

/// How a search result was matched, so the UI can show why a row appeared.
enum MatchSource { headword, alias, gloss, example }

class SearchResult {
  final DictionaryEntry entry;
  final MatchSource source;

  /// Populated when [source] is [MatchSource.alias] — the derived form that
  /// actually matched, e.g. searching "ɓolye" matches the plural of "ɓòòlé".
  final String? matchedAlias;

  const SearchResult(this.entry, this.source, {this.matchedAlias});
}

/// Opens the bundled SQLite dictionary and queries it.
///
/// All Bwaatiye-side lookups are accent-insensitive: the query is folded with
/// [fold] and compared against the pre-folded `search_key` / `alias_key`
/// columns, so "boole" finds "ɓòòlé" and "habye" finds "háɓyé".
class DictionaryRepository {
  static const _assetPath = 'assets/bwatiye_dictionary.db';
  static const _fileName = 'bwatiye_dictionary.db';

  Database? _db;

  Future<Database> open() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = join(dir.path, _fileName);

    // Copy the read-only bundled asset into a writable location on first run;
    // sqflite needs a real file path.
    if (!await File(path).exists()) {
      final data = await rootBundle.load(_assetPath);
      await File(path).writeAsBytes(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        flush: true,
      );
    }
    _db = await openDatabase(path, readOnly: true);
    return _db!;
  }

  // ---------------------------------------------------------------- hydration

  Future<DictionaryEntry> _hydrateOne(Map<String, dynamic> row) async {
    final db = await open();
    final id = row['id'] as String;
    final ex = await db.query('examples', where: 'entry_id = ?', whereArgs: [id]);
    final al = await db.query('aliases', where: 'entry_id = ?', whereArgs: [id]);
    final xr = await db
        .query('cross_references', where: 'entry_id = ?', whereArgs: [id]);
    return DictionaryEntry.fromMap(
      row,
      examples: ex.map(DictionaryExample.fromMap).toList(),
      aliases: al.map(EntryAlias.fromMap).toList(),
      crossReferences: xr.map(CrossReference.fromMap).toList(),
    );
  }

  /// Hydrates in bulk with three queries instead of three per row — this is
  /// the difference between a snappy and a janky results list.
  Future<List<DictionaryEntry>> _hydrate(List<Map<String, dynamic>> rows) async {
    if (rows.isEmpty) return [];
    final db = await open();
    final ids = rows.map((r) => r['id'] as String).toList();
    final ph = List.filled(ids.length, '?').join(',');

    final ex = await db.query('examples', where: 'entry_id IN ($ph)', whereArgs: ids);
    final al = await db.query('aliases', where: 'entry_id IN ($ph)', whereArgs: ids);
    final xr = await db.query('cross_references',
        where: 'entry_id IN ($ph)', whereArgs: ids);

    Map<String, List<T>> group<T>(
        List<Map<String, dynamic>> src, T Function(Map<String, dynamic>) f) {
      final m = <String, List<T>>{};
      for (final r in src) {
        (m[r['entry_id'] as String] ??= []).add(f(r));
      }
      return m;
    }

    final exM = group(ex, DictionaryExample.fromMap);
    final alM = group(al, EntryAlias.fromMap);
    final xrM = group(xr, CrossReference.fromMap);

    return rows
        .map((r) => DictionaryEntry.fromMap(
              r,
              examples: exM[r['id']] ?? const [],
              aliases: alM[r['id']] ?? const [],
              crossReferences: xrM[r['id']] ?? const [],
            ))
        .toList();
  }

  // ------------------------------------------------------------------ queries

  /// Alphabetical page of entries, ordered by the Bwaatiye alphabet.
  Future<List<DictionaryEntry>> browse({int limit = 100, int offset = 0}) async {
    final db = await open();
    return _hydrate(await db.query('entries',
        orderBy: 'sortkey ASC', limit: limit, offset: offset));
  }

  /// Entries whose sort key begins with [letter] — for the A–Z index bar.
  Future<List<DictionaryEntry>> browseLetter(String letter) async {
    final db = await open();
    return _hydrate(await db.query('entries',
        where: r"sortkey LIKE ? ESCAPE '\'",
        whereArgs: ['${escapeLike(fold(letter))}%'],
        orderBy: 'sortkey ASC'));
  }

  /// Exact headword lookup, accent-insensitive.
  Future<DictionaryEntry?> getByHeadword(String headword) async {
    final db = await open();
    final rows = await db.query('entries',
        where: 'search_key = ?', whereArgs: [fold(headword)], limit: 1);
    if (rows.isEmpty) return null;
    return _hydrateOne(rows.first);
  }

  Future<DictionaryEntry?> getById(String id) async {
    final db = await open();
    final rows =
        await db.query('entries', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return _hydrateOne(rows.first);
  }

  /// Follows a cross-reference to its target, or null when the source
  /// dictionary pointed at a form it never gave an entry to.
  Future<DictionaryEntry?> follow(CrossReference ref) =>
      ref.targetId == null ? Future.value(null) : getById(ref.targetId!);

  /// Type-ahead: headword prefix first, then alias prefix. Accent-insensitive.
  Future<List<SearchResult>> searchByPrefix(String prefix, {int limit = 50}) async {
    final db = await open();
    final p = '${escapeLike(fold(prefix))}%';
    if (fold(prefix).isEmpty) return [];

    final head = await db.query('entries',
        where: r"search_key LIKE ? ESCAPE '\'",
        whereArgs: [p],
        orderBy: 'sortkey',
        limit: limit);
    final results = (await _hydrate(head))
        .map((e) => SearchResult(e, MatchSource.headword))
        .toList();

    if (results.length >= limit) return results;
    final seen = results.map((r) => r.entry.id).toSet();

    final alias = await db.rawQuery('''
      SELECT e.*, a.alias AS matched_alias
      FROM aliases a JOIN entries e ON e.id = a.entry_id
      WHERE a.alias_key LIKE ? ESCAPE '\\' ORDER BY e.sortkey LIMIT ?
    ''', [p, limit - results.length]);

    for (final row in alias) {
      if (seen.contains(row['id'])) continue;
      seen.add(row['id'] as String);
      results.add(SearchResult(await _hydrateOne(row), MatchSource.alias,
          matchedAlias: row['matched_alias'] as String?));
    }
    return results;
  }

  /// Full search across headwords, derived forms, glosses and examples.
  ///
  /// Ranked so the most literal match wins: headword prefix, then headword
  /// substring, then alias, then gloss, then example text.
  Future<List<SearchResult>> search(String query, {int limit = 200}) async {
    final db = await open();
    final f = fold(query.trim());
    if (f.isEmpty) return [];
    final esc = escapeLike(f);
    final pre = '$esc%';
    final any = '%$esc%';

    final rows = await db.rawQuery('''
      SELECT e.*, r.rank, r.matched_alias FROM entries e JOIN (
        SELECT id, MIN(rank) AS rank, matched_alias FROM (
          SELECT id, 0 AS rank, NULL AS matched_alias FROM entries WHERE search_key LIKE ? ESCAPE '\\'
          UNION ALL
          SELECT id, 1, NULL FROM entries WHERE search_key LIKE ? ESCAPE '\\'
          UNION ALL
          SELECT a.entry_id, 2, a.alias FROM aliases a WHERE a.alias_key LIKE ? ESCAPE '\\'
          UNION ALL
          SELECT id, 3, NULL FROM entries WHERE gloss_key LIKE ? ESCAPE '\\'
          UNION ALL
          SELECT x.entry_id, 4, NULL FROM examples x
            WHERE LOWER(x.english) LIKE ? ESCAPE '\\' OR LOWER(x.bwatiye) LIKE ? ESCAPE '\\'
        ) GROUP BY id
      ) r ON r.id = e.id
      ORDER BY r.rank, e.sortkey
      LIMIT ?
    ''', [pre, any, any, any, any, any, limit]);

    const sources = [
      MatchSource.headword, MatchSource.headword, MatchSource.alias,
      MatchSource.gloss, MatchSource.example,
    ];
    final entries = await _hydrate(rows);
    return [
      for (var i = 0; i < entries.length; i++)
        SearchResult(entries[i], sources[(rows[i]['rank'] as int).clamp(0, 4)],
            matchedAlias: rows[i]['matched_alias'] as String?)
    ];
  }

  /// English-side lookup, so the app offers reverse search without needing the
  /// printed English index transcribed.
  Future<List<DictionaryEntry>> searchEnglish(String query, {int limit = 200}) async {
    final db = await open();
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return [];
    final esc = escapeLike(q);
    return _hydrate(await db.rawQuery('''
      SELECT * FROM entries
      WHERE gloss_key LIKE ? ESCAPE '\\' OR gloss_key LIKE ? ESCAPE '\\'
      ORDER BY CASE WHEN gloss_key LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, gloss_key
      LIMIT ?
    ''', ['$esc%', '%$esc%', '$esc%', limit]));
  }

  Future<int> count() async {
    final db = await open();
    return Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM entries')) ??
        0;
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
