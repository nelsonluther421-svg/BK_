import 'package:flutter/material.dart';

import 'app.dart';
import 'dictionary_repository.dart';
import 'services/preferences_service.dart';
import 'services/voice_recording_service.dart';
import 'state/app_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final controller = AppController(
    repository: DictionaryRepository(),
    preferences: PreferencesService(),
    voice: VoiceRecordingService(),
  );

  runApp(KwaBwatiyeApp(controller: controller));
  await controller.initialize();
}
