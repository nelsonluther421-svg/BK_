import 'package:flutter/material.dart';

abstract final class AppColors {
  static const ink = Color(0xFF1E2823);
  static const forest = Color(0xFF214D3D);
  static const forestDark = Color(0xFF15352B);
  static const clay = Color(0xFF9B432E);
  static const clayDark = Color(0xFF713022);
  static const gold = Color(0xFFD49A3F);
  static const goldSoft = Color(0xFFF0D8A9);
  static const cream = Color(0xFFF9F2E5);
  static const paper = Color(0xFFFFFCF6);
  static const muted = Color(0xFF6F716C);
  static const line = Color(0xFFE6DCCB);
}

abstract final class AppTheme {
  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.clay,
      brightness: Brightness.light,
      primary: AppColors.clay,
      secondary: AppColors.gold,
      surface: AppColors.paper,
      onSurface: AppColors.ink,
    );

    final base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.cream,
    );

    return base.copyWith(
      textTheme: base.textTheme.copyWith(
        displayLarge: const TextStyle(
          fontFamily: 'serif',
          color: AppColors.ink,
          fontSize: 56,
          height: 0.98,
          letterSpacing: -1.8,
          fontWeight: FontWeight.w600,
        ),
        headlineLarge: const TextStyle(
          fontFamily: 'serif',
          color: AppColors.ink,
          fontSize: 34,
          height: 1.05,
          fontWeight: FontWeight.w600,
        ),
        headlineMedium: const TextStyle(
          fontFamily: 'serif',
          color: AppColors.ink,
          fontSize: 27,
          fontWeight: FontWeight.w600,
        ),
        titleLarge: const TextStyle(
          color: AppColors.ink,
          fontSize: 20,
          fontWeight: FontWeight.w800,
        ),
        titleMedium: const TextStyle(
          color: AppColors.ink,
          fontSize: 16,
          fontWeight: FontWeight.w700,
        ),
        bodyLarge: const TextStyle(
          color: AppColors.ink,
          fontSize: 16,
          height: 1.55,
        ),
        bodyMedium: const TextStyle(
          color: AppColors.muted,
          fontSize: 14,
          height: 1.5,
        ),
        labelLarge: const TextStyle(
          fontWeight: FontWeight.w800,
          letterSpacing: 0.2,
        ),
      ),
      appBarTheme: const AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        backgroundColor: AppColors.cream,
        foregroundColor: AppColors.ink,
        surfaceTintColor: Colors.transparent,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.paper,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
        hintStyle: const TextStyle(color: Color(0xFF96958F)),
        prefixIconColor: AppColors.clay,
        suffixIconColor: AppColors.muted,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: AppColors.line),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: AppColors.line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: AppColors.gold, width: 1.8),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.clay,
          foregroundColor: Colors.white,
          minimumSize: const Size(0, 54),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 72,
        backgroundColor: AppColors.paper,
        indicatorColor: AppColors.goldSoft,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          return TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: states.contains(WidgetState.selected)
                ? AppColors.clayDark
                : AppColors.muted,
          );
        }),
      ),
      dividerColor: AppColors.line,
    );
  }
}

class BrandMark extends StatelessWidget {
  const BrandMark({super.key, this.size = 44, this.onDark = false});

  final double size;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: 0.785398,
      child: Container(
        width: size,
        height: size,
        padding: EdgeInsets.all(size * 0.16),
        decoration: BoxDecoration(
          color: onDark ? const Color(0x15FFFFFF) : AppColors.paper,
          border: Border.all(
            color: onDark ? const Color(0x33FFFFFF) : AppColors.line,
          ),
          borderRadius: BorderRadius.circular(size * 0.2),
        ),
        child: GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          mainAxisSpacing: size * 0.07,
          crossAxisSpacing: size * 0.07,
          children: const [
            _BrandTile(AppColors.clay),
            _BrandTile(AppColors.gold),
            _BrandTile(AppColors.gold),
            _BrandTile(AppColors.forest),
          ],
        ),
      ),
    );
  }
}

class _BrandTile extends StatelessWidget {
  const _BrandTile(this.color);

  final Color color;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }
}
