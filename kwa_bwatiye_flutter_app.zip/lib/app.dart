import 'package:flutter/material.dart';

import 'screens/app_shell.dart';
import 'screens/welcome_screen.dart';
import 'state/app_controller.dart';
import 'theme/app_theme.dart';

class KwaBwatiyeApp extends StatelessWidget {
  const KwaBwatiyeApp({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      controller: controller,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Kwa Bwatiye',
        theme: AppTheme.light,
        home: AnimatedBuilder(
          animation: controller,
          builder: (context, _) {
            if (!controller.isReady) return const _LaunchScreen();
            if (!controller.hasCompletedWelcome) {
              return WelcomeScreen(onContinue: controller.completeWelcome);
            }
            return const AppShell();
          },
        ),
      ),
    );
  }
}

class AppScope extends InheritedNotifier<AppController> {
  const AppScope({
    super.key,
    required AppController controller,
    required super.child,
  }) : super(notifier: controller);

  static AppController of(BuildContext context, {bool listen = true}) {
    if (listen) {
      final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
      assert(scope != null, 'AppScope was not found above this context.');
      return scope!.notifier!;
    }
    final element = context.getElementForInheritedWidgetOfExactType<AppScope>();
    final scope = element?.widget as AppScope?;
    assert(scope != null, 'AppScope was not found above this context.');
    return scope!.notifier!;
  }
}

class _LaunchScreen extends StatelessWidget {
  const _LaunchScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppColors.ink,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            BrandMark(size: 68, onDark: true),
            SizedBox(height: 20),
            Text(
              'KWA BWATIYE',
              style: TextStyle(
                color: AppColors.cream,
                fontWeight: FontWeight.w800,
                letterSpacing: 3,
              ),
            ),
            SizedBox(height: 18),
            SizedBox(
              width: 84,
              child: LinearProgressIndicator(
                minHeight: 2,
                color: AppColors.gold,
                backgroundColor: Color(0x33FFFFFF),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
