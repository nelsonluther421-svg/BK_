/// Text helpers for Bwaatiye orthography.
///
/// The dictionary writes tone with combining accents (á à â) and uses the
/// hooked letters ɓ ɗ plus ö and ü. Nobody types those on a phone keyboard,
/// so every search path folds both the query and the stored key down to plain
/// ASCII before comparing. The folded form is what lives in
/// `entries.search_key`, `entries.gloss_key` and `aliases.alias_key`.
library bwatiye_text;

const Map<String, String> _special = {
  'ɓ': 'b', 'Ɓ': 'b',
  'ɗ': 'd', 'Ɗ': 'd',
  'ö': 'o', 'Ö': 'o',
  'ü': 'u', 'Ü': 'u',
  'ŋ': 'ng', 'Ŋ': 'ng',
  '\u2019': "'", '\u2018': "'",
};

/// Maps precomposed Latin letters to their base form. Dart has no
/// `String.normalize`, so the common accented codepoints are listed directly.
const Map<String, String> _accented = {
  'á': 'a', 'à': 'a', 'â': 'a', 'ä': 'a', 'ã': 'a', 'å': 'a', 'ā': 'a',
  'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e', 'ē': 'e',
  'í': 'i', 'ì': 'i', 'î': 'i', 'ï': 'i', 'ī': 'i',
  'ó': 'o', 'ò': 'o', 'ô': 'o', 'õ': 'o', 'ō': 'o',
  'ú': 'u', 'ù': 'u', 'û': 'u', 'ū': 'u',
  'ý': 'y', 'ỳ': 'y', 'ÿ': 'y',
  'ñ': 'n', 'ç': 'c',
};

/// Combining diacritical marks (U+0300–U+036F), stripped when text arrives
/// already decomposed.
bool _isCombining(int cu) => cu >= 0x0300 && cu <= 0x036F;

/// Folds [input] to a lowercase, accent-free, hook-free ASCII form.
///
/// ```dart
/// fold('ɓòòlé')  // 'boole'
/// fold('háɓyé')  // 'habye'
/// ```
String fold(String? input) {
  if (input == null || input.isEmpty) return '';
  final out = StringBuffer();
  for (final rune in input.runes) {
    final ch = String.fromCharCode(rune);
    if (_isCombining(rune)) continue;
    final mapped = _special[ch] ?? _accented[ch.toLowerCase()] ?? ch;
    out.write(mapped.toLowerCase());
  }
  return out.toString();
}

/// Folds and also drops bracketing and punctuation, so a cross-reference like
/// `(à)hyékútö` compares equal to the headword `hyekutö`.
String foldLoose(String? input) {
  final f = fold(input);
  return f.replaceAll(RegExp(r'[()\[\].,;:]'), '').trim();
}

/// Escapes `%` and `_` so user input can go straight into a LIKE pattern.
String escapeLike(String input) =>
    input.replaceAll(r'\', r'\\').replaceAll('%', r'\%').replaceAll('_', r'\_');

/// Letters of the Bwaatiye alphabet in the order the source dictionary uses.
/// Note that ɓ and ɗ sort as their own letters, after b and d respectively.
const List<String> bwatiyeAlphabet = [
  'a', 'b', 'ɓ', 'c', 'd', 'ɗ', 'e', 'f', 'g', 'gb', 'h', 'i', 'j',
  'k', 'kp', 'l', 'm', 'n', 'o', 'ö', 'p', 'r', 's', 'sh', 't',
  'u', 'ü', 'v', 'w', 'y', 'z',
];
