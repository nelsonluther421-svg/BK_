import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

import '../app.dart';
import '../models/dictionary_entry.dart';
import '../services/voice_recording_service.dart';
import '../theme/app_theme.dart';

class VoiceRecordingCard extends StatefulWidget {
  const VoiceRecordingCard({super.key, required this.entry});

  final DictionaryEntry entry;

  @override
  State<VoiceRecordingCard> createState() => _VoiceRecordingCardState();
}

class _VoiceRecordingCardState extends State<VoiceRecordingCard> {
  VoiceRecordingService? _voice;
  StreamSubscription<PlayerState>? _playerSubscription;
  Timer? _timer;
  bool _hasRecording = false;
  bool _recording = false;
  bool _playing = false;
  int _seconds = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_voice != null) return;
    _voice = AppScope.of(context, listen: false).voice;
    _playerSubscription = _voice!.playerState.listen((state) {
      if (!mounted) return;
      setState(() => _playing = state == PlayerState.playing);
    });
    _refresh();
  }

  Future<void> _refresh() async {
    final exists = await _voice!.hasRecording(widget.entry.id);
    if (mounted) setState(() => _hasRecording = exists);
  }

  Future<void> _toggleRecording() async {
    if (_recording) {
      await _voice!.stop();
      _timer?.cancel();
      if (!mounted) return;
      setState(() {
        _recording = false;
        _hasRecording = true;
      });
      return;
    }

    final allowed = await _voice!.start(widget.entry.id);
    if (!mounted) return;
    if (!allowed) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Microphone permission is needed to record a pronunciation.'),
        ),
      );
      return;
    }

    setState(() {
      _recording = true;
      _playing = false;
      _seconds = 0;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _seconds += 1);
    });
  }

  Future<void> _togglePlayback() async {
    if (_playing) {
      await _voice!.stopPlayback();
    } else {
      await _voice!.play(widget.entry.id);
    }
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Delete local recording?'),
            content: Text(
              'This removes the pronunciation draft for “${widget.entry.headword}” from this device.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Delete'),
              ),
            ],
          ),
        ) ??
        false;
    if (!confirmed) return;
    await _voice!.delete(widget.entry.id);
    if (mounted) setState(() => _hasRecording = false);
  }

  String get _elapsed {
    final minutes = _seconds ~/ 60;
    final seconds = (_seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _timer?.cancel();
    _playerSubscription?.cancel();
    if (_recording) _voice?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: AppColors.ink,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'VOICE & PRONUNCIATION',
                        style: TextStyle(
                          color: AppColors.gold,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.25,
                        ),
                      ),
                      SizedBox(height: 7),
                      Text(
                        'Community voice draft',
                        style: TextStyle(
                          color: AppColors.cream,
                          fontFamily: 'serif',
                          fontSize: 21,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                if (_hasRecording)
                  IconButton(
                    tooltip: 'Delete recording',
                    onPressed: _delete,
                    color: const Color(0xAAFFFFFF),
                    icon: const Icon(Icons.delete_outline_rounded),
                  ),
              ],
            ),
          ),
          _Waveform(active: _recording || _playing),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  _recording
                      ? 'Recording $_elapsed · say the word clearly'
                      : _hasRecording
                          ? 'A local recording is ready to play.'
                          : 'No recording yet. Capture a fluent speaker when ready.',
                  style: const TextStyle(
                    color: Color(0xBFFFFFFF),
                    fontSize: 11,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _toggleRecording,
                        style: FilledButton.styleFrom(
                          backgroundColor: _recording
                              ? const Color(0xFFD85C4C)
                              : AppColors.gold,
                          foregroundColor: AppColors.ink,
                        ),
                        icon: Icon(
                          _recording ? Icons.stop_rounded : Icons.mic_rounded,
                        ),
                        label: Text(_recording ? 'Stop' : 'Record'),
                      ),
                    ),
                    if (_hasRecording && !_recording) ...[
                      const SizedBox(width: 10),
                      IconButton.filledTonal(
                        tooltip: _playing ? 'Stop playback' : 'Play recording',
                        onPressed: _togglePlayback,
                        style: IconButton.styleFrom(
                          backgroundColor: const Color(0x22FFFFFF),
                          foregroundColor: AppColors.cream,
                        ),
                        icon: Icon(
                          _playing ? Icons.stop_rounded : Icons.play_arrow_rounded,
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  'Stored only on this device. A draft is not treated as a verified dictionary pronunciation.',
                  style: TextStyle(color: Color(0x77FFFFFF), fontSize: 9, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Waveform extends StatelessWidget {
  const _Waveform({required this.active});

  final bool active;

  @override
  Widget build(BuildContext context) {
    const heights = <double>[12, 22, 34, 18, 46, 28, 58, 37, 20, 50, 31, 43, 16, 38, 54, 24, 42, 19, 32];
    return SizedBox(
      height: 78,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (var index = 0; index < heights.length; index++)
            AnimatedContainer(
              duration: Duration(milliseconds: 280 + (index % 4) * 70),
              curve: Curves.easeInOut,
              width: 3,
              height: active
                  ? heights[index] * (index.isEven ? 1.0 : 0.72)
                  : heights[index] * 0.42,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: active ? AppColors.gold : const Color(0x77D49A3F),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
        ],
      ),
    );
  }
}
