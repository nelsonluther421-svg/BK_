import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

class VoiceRecordingService {
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();

  Stream<PlayerState> get playerState => _player.onPlayerStateChanged;

  Future<Directory> _recordingDirectory() async {
    final documents = await getApplicationDocumentsDirectory();
    final directory = Directory(path.join(documents.path, 'bwatiye_voice_archive'));
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  Future<String> pathFor(String entryId) async {
    final directory = await _recordingDirectory();
    return path.join(directory.path, '$entryId.m4a');
  }

  Future<bool> hasRecording(String entryId) async {
    return File(await pathFor(entryId)).exists();
  }

  Future<bool> start(String entryId) async {
    if (!await _recorder.hasPermission()) return false;
    await _player.stop();
    final outputPath = await pathFor(entryId);
    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc,
        bitRate: 128000,
        sampleRate: 44100,
      ),
      path: outputPath,
    );
    return true;
  }

  Future<String?> stop() => _recorder.stop();

  Future<void> cancel() => _recorder.cancel();

  Future<void> play(String entryId) async {
    final filePath = await pathFor(entryId);
    if (!await File(filePath).exists()) return;
    await _player.stop();
    await _player.play(DeviceFileSource(filePath));
  }

  Future<void> stopPlayback() => _player.stop();

  Future<void> delete(String entryId) async {
    await _player.stop();
    final file = File(await pathFor(entryId));
    if (await file.exists()) await file.delete();
  }

  Future<List<String>> recordedEntryIds() async {
    final directory = await _recordingDirectory();
    final ids = <String>[];
    await for (final entity in directory.list()) {
      if (entity is File && path.extension(entity.path).toLowerCase() == '.m4a') {
        ids.add(path.basenameWithoutExtension(entity.path));
      }
    }
    ids.sort();
    return ids;
  }

  Future<void> dispose() async {
    await _recorder.dispose();
    await _player.dispose();
  }
}
