import 'package:shared_preferences/shared_preferences.dart';

class PreferencesService {
  static const _welcomeKey = 'welcome_completed_v1';
  static const _favoritesKey = 'favorite_entry_ids_v1';

  Future<bool> hasCompletedWelcome() async {
    final preferences = await SharedPreferences.getInstance();
    return preferences.getBool(_welcomeKey) ?? false;
  }

  Future<void> setWelcomeCompleted() async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setBool(_welcomeKey, true);
  }

  Future<Set<String>> loadFavoriteIds() async {
    final preferences = await SharedPreferences.getInstance();
    return (preferences.getStringList(_favoritesKey) ?? const <String>[]).toSet();
  }

  Future<void> saveFavoriteIds(Set<String> ids) async {
    final preferences = await SharedPreferences.getInstance();
    final sorted = ids.toList()..sort();
    await preferences.setStringList(_favoritesKey, sorted);
  }
}
