/// A single Bwaatiye–English dictionary entry, plus its related rows.
class DictionaryEntry {
  final String id;
  final String headword;

  /// Diacritic-free form used for A–Z ordering and browse grouping.
  final String sortkey;

  /// Diacritic-free form used for accent-insensitive matching.
  final String searchKey;

  final String? pos;
  final String gloss;
  final String? plural;
  final String? scientificName;
  final String? notes;

  /// Page in the printed dictionary the entry came from, for citation.
  final int? sourcePage;

  final String direction;
  final List<DictionaryExample> examples;

  /// Derived forms (plural, feminine, verbal noun, orthographic variant)
  /// that point back at this entry. These are searchable in their own right.
  final List<EntryAlias> aliases;

  final List<CrossReference> crossReferences;

  const DictionaryEntry({
    required this.id,
    required this.headword,
    required this.sortkey,
    required this.searchKey,
    this.pos,
    required this.gloss,
    this.plural,
    this.scientificName,
    this.notes,
    this.sourcePage,
    this.direction = 'bwa-eng',
    this.examples = const [],
    this.aliases = const [],
    this.crossReferences = const [],
  });

  factory DictionaryEntry.fromMap(
    Map<String, dynamic> row, {
    List<DictionaryExample> examples = const [],
    List<EntryAlias> aliases = const [],
    List<CrossReference> crossReferences = const [],
  }) {
    return DictionaryEntry(
      id: row['id'] as String,
      headword: row['headword'] as String,
      sortkey: row['sortkey'] as String,
      searchKey: (row['search_key'] as String?) ?? '',
      pos: row['pos'] as String?,
      gloss: row['gloss'] as String,
      plural: row['plural'] as String?,
      scientificName: row['scientific_name'] as String?,
      notes: row['notes'] as String?,
      sourcePage: row['source_page'] as int?,
      direction: (row['direction'] as String?) ?? 'bwa-eng',
      examples: examples,
      aliases: aliases,
      crossReferences: crossReferences,
    );
  }
}

class DictionaryExample {
  final String? bwatiye;
  final String? english;
  const DictionaryExample({this.bwatiye, this.english});

  factory DictionaryExample.fromMap(Map<String, dynamic> r) => DictionaryExample(
        bwatiye: r['bwatiye'] as String?,
        english: r['english'] as String?,
      );
}

/// A derived form of a headword — e.g. `ɓolye` is the plural alias of `ɓòòlé`.
class EntryAlias {
  final String alias;

  /// 'plural' | 'variant' | 'verbal noun' | 'feminine' | 'masculine' |
  /// 'singular' | 'noun form' | 'form'
  final String? label;

  const EntryAlias({required this.alias, this.label});

  factory EntryAlias.fromMap(Map<String, dynamic> r) => EntryAlias(
        alias: r['alias'] as String,
        label: r['label'] as String?,
      );
}

/// A "see also" pointer from one entry to another.
class CrossReference {
  /// The reference exactly as the source dictionary printed it.
  final String refText;

  /// Resolved target entry id, or null when the printed dictionary points at
  /// a form it never gave its own entry to. Render those as plain text, not
  /// as a broken tap target.
  final String? targetId;

  /// How the link was established: 'exact', 'h-alternation', 'stem',
  /// 'stem-prefix', 'head-word'. Anything other than 'exact' was inferred and
  /// is worth a reviewer's eye.
  final String? matchKind;

  const CrossReference({required this.refText, this.targetId, this.matchKind});

  bool get isResolved => targetId != null;
  bool get isInferred => matchKind != null && matchKind != 'exact';

  factory CrossReference.fromMap(Map<String, dynamic> r) => CrossReference(
        refText: r['ref_text'] as String,
        targetId: r['target_id'] as String?,
        matchKind: r['match_kind'] as String?,
      );
}
