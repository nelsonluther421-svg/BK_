import 'package:flutter/foundation.dart';

import '../dictionary_repository.dart';
import '../services/preferences_service.dart';
import '../services/voice_recording_service.dart';

class AppController extends ChangeNotifier {
  AppController({
    required this.repository,
    required this.preferences,
    required this.voice,
  });

  final DictionaryRepository repository;
  final PreferencesService preferences;
  final VoiceRecordingService voice;

  bool isReady = false;
  bool hasCompletedWelcome = false;
  int dictionaryCount = 0;
  Set<String> favoriteIds = <String>{};
  Object? startupError;

  Future<void> initialize() async {
    try {
      final results = await Future.wait<Object>([
        preferences.hasCompletedWelcome(),
        preferences.loadFavoriteIds(),
        repository.open(),
      ]);
      hasCompletedWelcome = results[0] as bool;
      favoriteIds = results[1] as Set<String>;
      dictionaryCount = await repository.count();
    } catch (error) {
      startupError = error;
    } finally {
      isReady = true;
      notifyListeners();
    }
  }

  Future<void> retryInitialization() async {
    isReady = false;
    startupError = null;
    notifyListeners();
    await initialize();
  }

  Future<void> completeWelcome() async {
    hasCompletedWelcome = true;
    notifyListeners();
    await preferences.setWelcomeCompleted();
  }

  bool isFavorite(String entryId) => favoriteIds.contains(entryId);

  Future<void> toggleFavorite(String entryId) async {
    if (favoriteIds.contains(entryId)) {
      favoriteIds.remove(entryId);
    } else {
      favoriteIds.add(entryId);
    }
    favoriteIds = Set<String>.of(favoriteIds);
    notifyListeners();
    await preferences.saveFavoriteIds(favoriteIds);
  }

  @override
  void dispose() {
    repository.close();
    voice.dispose();
    super.dispose();
  }
}
