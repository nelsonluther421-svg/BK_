package com.kwabwatiye.dictionary

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
