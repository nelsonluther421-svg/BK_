# Kwa Bwatiye — Bachama–English Dictionary

A mobile-first Flutter dictionary built around the supplied Bwaatiye data package. The app works offline and keeps the dictionary source intact.

## What is included

- First-launch cultural welcome screen with **“Bware Hido, Jiya Hido”** and **“Wayam Pepe”**
- 2,132 Bwaatiye–English dictionary entries
- Accent-insensitive search for special Bwaatiye letters and tone marks
- English reverse lookup using the supplied glosses
- Browse by the Bwaatiye alphabet, including `ɓ`, `ɗ`, `ö`, `ü`, `gb`, `kp`, and `sh`
- Entry pages with parts of speech, plural forms, scientific names, notes, examples, aliases, cross-references, and source-page citations
- Saved words stored on the device
- Word of the day drawn from the real dictionary
- Local pronunciation recording, playback, deletion, and voice archive
- Clear distinction between local voice drafts and verified dictionary information
- Responsive Material 3 interface designed for Android phones

## Data source

The bundled data restructures the Bwaatiye–English Dictionary by Nicholas Pweddon and A. Neil Skinner. It covers printed pages 1–101 of the Bwaatiye-to-English section.

The package includes:

- `assets/bwatiye_dictionary.db` — runtime SQLite database
- `assets/bwatiye_dictionary.json` — structured backup/reference data
- 612 searchable aliases or derived forms
- 529 example phrases
- 223 cross-references, including unresolved references retained from the printed source

No dictionary words or definitions were invented for the interface.

## Windows setup

Requirements:

- Flutter SDK 3.35 or newer
- Android Studio with an Android SDK and emulator, or an Android phone with USB debugging
- VS Code with Flutter and Dart extensions

From PowerShell in this folder, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_windows.ps1
flutter run
```

The setup script completes any Flutter-generated Android wrapper files, downloads packages, runs static analysis, and runs the tests.

## Manual setup

```powershell
flutter create . --platforms=android --project-name kwa_bwatiye --org com.kwabwatiye
flutter pub get
flutter analyze
flutter test
flutter run
```

The checked-in Android manifest already contains the microphone permission required by the voice archive. If `flutter create` reports that files already exist, that is expected.

## Build an APK

For a test APK:

```powershell
flutter build apk --debug
```

For a Play Store release, replace the temporary debug signing configuration in `android/app/build.gradle.kts` with your own release key, then run:

```powershell
flutter build appbundle --release
```

## Important behavior

- Dictionary search and browsing work without internet access.
- Saved words use device preferences.
- Voice files are stored in the app's private documents directory.
- Deleting the app may remove its local voice recordings unless the device backs up app data.
- Recordings are not uploaded and are never treated as verified automatically.
- Android 7.0 / API 24 is the minimum supported Android version.

## Project structure

```text
lib/
  main.dart
  app.dart
  dictionary_repository.dart
  bwatiye_text.dart
  models/
  screens/
  services/
  state/
  theme/
  widgets/
assets/
  bwatiye_dictionary.db
  bwatiye_dictionary.json
android/
test/
```
